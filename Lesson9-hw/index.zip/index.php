﻿<?php
    phpinfo();
